package com.imooc.o2o;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class O2oApplicationTests {

	@Test
	public void contextLoads() {
	}

}
